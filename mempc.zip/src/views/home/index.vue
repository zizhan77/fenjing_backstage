<template>
  <section>home</section>
</template>

<script>
export default {
  created() {}
};
</script>
