<template>
  <section class="banner">
    <router-view></router-view>
  </section>
</template>