<template>
  <section class="operation">
    <router-view></router-view>
  </section>
</template>