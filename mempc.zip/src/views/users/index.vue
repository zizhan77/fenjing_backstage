<template>
  <section class="user">
    <router-view />
  </section>
</template>
