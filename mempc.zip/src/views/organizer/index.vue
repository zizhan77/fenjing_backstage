<template>
  <section class="sponsor">
    <router-view></router-view>
  </section>
</template>