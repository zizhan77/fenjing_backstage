<template>
  <section class="app-main">main</section>
</template>
<style lang="scss">
.app-main {
  padding: 16px;
  min-height: calc(100vh - 50px);
  width: 100%;
  overflow: hidden;
  background: #f3f4f7;
}
</style>
