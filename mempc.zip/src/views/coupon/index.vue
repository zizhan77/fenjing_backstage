<template>
  <section class="coupon">
    <router-view></router-view>
  </section>
</template>
