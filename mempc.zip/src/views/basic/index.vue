<template>
  <section class="basic">
    <router-view></router-view>
  </section>
</template>
 