<template>
  <section class="freight">
    <router-view></router-view>
  </section>
</template>