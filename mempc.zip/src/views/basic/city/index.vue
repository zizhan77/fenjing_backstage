<template>
  <section class="city">
    <router-view></router-view>
  </section>
</template>