<template>
  <section class="actor">
    <router-view></router-view>
  </section>
</template>