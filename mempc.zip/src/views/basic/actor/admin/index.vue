<template>
  <section class="basic-admin">
    <router-view></router-view>
  </section>
</template>