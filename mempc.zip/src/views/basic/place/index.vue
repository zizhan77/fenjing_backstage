<template>
  <section class="place">
    <router-view></router-view>
  </section>
</template>