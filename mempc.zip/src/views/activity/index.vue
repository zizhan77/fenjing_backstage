<template>
  <section class="activity">
    <router-view></router-view>
  </section>
</template>