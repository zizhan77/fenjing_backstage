<template>
  <section class="show">
    <router-view></router-view>
  </section>
</template>