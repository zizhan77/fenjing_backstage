<template>
  <section class="ticket">
    <router-view></router-view>
  </section>
</template>