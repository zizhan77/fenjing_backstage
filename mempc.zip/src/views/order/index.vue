<template>
  <section class="order">
    <router-view></router-view>
  </section>
</template>