export default {
  // 登陆
  login: 'login/pc/getToken',
  // 查询登陆信息
  getInfo: 'login/pc/getInfo'
}