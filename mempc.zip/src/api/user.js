export default {
  // 查询用户列表
  queryUserList: 'user/queryUserList',
  // 查询操作记录
  queryOptRecord: 'user/queryOptRecord',
  // 冻结用户
  updateUserStatus: 'user/updateUserStatus',
  queryUserNew: 'activityShare/pc/queryShareAddUserList',
  // 查询当前用户的抽奖次数
  queryUserChouj: 'user/pc/userSelectLottery',
  // 设置饭团数
  setFantuan: 'user/pc/updateUserIntegral',
  // 设置抽奖
  setChouj: 'user/pc/Updatelottery'

}
