export default {
  // 查询验票员列表
  queryList: 'checkman/queryCheckManList',
  // 新增/更新验票员信息
  addOrUpdateCheckMan: 'checkman/addOrUpdateCheckMan'
}