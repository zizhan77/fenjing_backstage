export default {
  // 开屏页列表
  queryOpeningPage: 'banner/queryOpeningPage',
  // 删除开屏页
  deleteById: 'banner/deleteById',
  // 新建编辑开屏页
  addOrUpdate: 'banner/addOrUpdate',
  // 查询省市
  queryListByParent: 'basic/address/queryListByParent'
}