export default {
  // 赞助商列表
  sponsorList: 'organizer/queryAll',
  // 增加赞助商
  sponsorAdd: 'organizer/saveOrUpdate',
  // 更新赞助商
  updateById: 'organizer/saveOrUpdate',
  // 查询赞助商信息
  querySponsor: 'organizer/queryBy'
}