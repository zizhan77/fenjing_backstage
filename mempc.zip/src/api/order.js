// 订单
export default {
  // 查订单列表
  getOrderListByPage: 'order/getOrderListByPage',
  // 修改订单信息
  editOrderBillCode: 'order/editOrderBillCode'
}