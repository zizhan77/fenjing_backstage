export default {
  // 查询演出列表
  getShowList: 'ranking/queryPage',  
  // 查询演出
  getDetail: 'ranking/queryPage',
  // 上传图片
  uploadFile: 'file/uploadFile',
  updateEnable: 'ranking/edit',
  // 新增演出
  addPerformance: 'ranking/edit'
}